# 📖 字幕提取器 - 开发文档

> 本文档面向开发者和 AI 助手，详细说明项目架构、核心模块、数据流和扩展指南。

---

## 目录

1. [项目概述](#项目概述)
2. [技术架构](#技术架构)
3. [核心模块详解](#核心模块详解)
4. [数据流分析](#数据流分析)
5. [API 参考](#api-参考)
6. [开发指南](#开发指南)
7. [调试技巧](#调试技巧)
8. [常见问题](#常见问题)

---

## 项目概述

### 功能定位

字幕提取器是一个 Chrome 浏览器扩展（Manifest V3），主要功能：

1. **字幕拦截**：通过代理 `fetch` 和 `XMLHttpRequest`，自动拦截 YouTube/Bilibili 的字幕请求
2. **字幕下载**：解析多种字幕格式，提供纯文本下载
3. **AI 总结**：调用 OpenAI 兼容 API，对字幕内容进行流式总结

### 技术选型

| 技术 | 选择 | 理由 |
|------|------|------|
| 扩展规范 | Manifest V3 | Chrome 最新要求，安全性更高 |
| 脚本语言 | 原生 JavaScript | 无需构建工具，开发简单 |
| 样式方案 | 原生 CSS | 完全控制，无依赖 |
| AI 通信 | SSE 流式 | 实时输出，用户体验好 |

---

## 技术架构

### 文件职责矩阵

```
┌─────────────────────────────────────────────────────────────────┐
│                        Chrome Extension                         │
├─────────────────────────────────────────────────────────────────┤
│  manifest.json          扩展配置，声明权限和脚本               │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │ background  │  │   popup     │  │  options    │              │
│  │    .js      │  │ .html/.js   │  │ .html/.js   │              │
│  │             │  │   /.css     │  │   /.css     │              │
│  │ Service     │  │ 弹出窗口    │  │ 设置页面    │              │
│  │ Worker      │  │ 用户交互    │  │ 配置管理    │              │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │
│         │                │                │                      │
│         └────────────────┼────────────────┘                      │
│                          │                                       │
│                   chrome.runtime API                             │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Content Scripts                       │    │
│  │  ┌─────────────────┐    ┌─────────────────────────┐     │    │
│  │  │ content_script  │───▶│      inject.js          │     │    │
│  │  │     .js         │    │ (injected into page)    │     │    │
│  │  │ 桥接通信        │    │ 拦截网络请求            │     │    │
│  │  └─────────────────┘    └─────────────────────────┘     │    │
│  └─────────────────────────────────────────────────────────┘    │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Shared Modules                        │    │
│  │  ┌─────────────┐         ┌─────────────────────┐        │    │
│  │  │  utils.js   │         │   chrome-api.js     │        │    │
│  │  │ 公共函数    │         │ Promise 封装        │        │    │
│  │  └─────────────┘         └─────────────────────┘        │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 权限说明

```json
{
  "permissions": [
    "storage",      // 本地存储配置和字幕数据
    "activeTab",    // 获取当前标签页信息
    "scripting"     // 动态注入脚本
  ],
  "host_permissions": [
    "*://*.youtube.com/*",
    "*://*.bilibili.com/*",
    "*://*.hdslb.com/*"     // Bilibili CDN
  ]
}
```

---

## 核心模块详解

### 1. inject.js - 网络请求拦截器

**职责**：代理浏览器原生的 `fetch` 和 `XMLHttpRequest`，拦截字幕请求。

**工作原理**：

```javascript
// 代理 fetch
const originalFetch = window.fetch;
window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    
    // 检查 URL 是否匹配字幕特征
    if (isSubtitleUrl(args[0])) {
        const clonedResponse = response.clone();
        const data = await clonedResponse.text();
        
        // 发送给 content script
        window.postMessage({
            type: 'SUBTITLE_CAPTURED',
            url: args[0],
            data: data
        }, '*');
    }
    
    return response;
};
```

**字幕 URL 特征匹配**：

| 平台 | URL 特征 |
|------|----------|
| YouTube | 包含 `timedtext` 或 `srv3` |
| Bilibili | 包含 `subtitle` 且以 `.json` 结尾 |

### 2. content_script.js - 消息桥接器

**职责**：连接页面上下文（inject.js）和扩展上下文（background.js）。

**通信流程**：

```
inject.js (页面上下文)
    │
    │ window.postMessage()
    ▼
content_script.js (内容脚本上下文)
    │
    │ chrome.runtime.sendMessage()
    ▼
background.js (Service Worker 上下文)
```

### 3. background.js - 后台服务

**职责**：

1. 缓存字幕数据（内存 + chrome.storage）
2. 处理 AI API 请求代理
3. 管理扩展图标 Badge

**核心功能模块**：

```javascript
// 1. 字幕存储
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'subtitle-found') {
        // 存储到内存缓存和 chrome.storage
    }
});

// 2. AI 连接测试
if (message.action === 'testConnection') {
    // 发送测试请求，返回延迟和状态
}

// 3. 流式 AI 总结
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'summarize-stream') {
        // 建立 SSE 流式连接
    }
});
```

### 4. popup.js - 弹出窗口逻辑

**职责**：用户交互界面，包括字幕选择、下载和 AI 总结。

**状态管理**：

```javascript
// 字幕数据来源
chrome.storage.local.get([`subtitles_${tabId}`], (result) => {
    const subtitles = result[key] || [];
    // 渲染列表...
});

// AI 流式输出
const port = chrome.runtime.connect({ name: 'summarize-stream' });
port.onMessage.addListener((msg) => {
    if (msg.type === 'chunk') {
        // 追加内容并渲染
    }
});
```

### 5. utils.js - 公共工具模块

**导出函数**：

| 函数 | 用途 |
|------|------|
| `markdownToHtml(md)` | 将 Markdown 转换为 HTML |
| `extractSubtitleText(data, url)` | 从原始字幕数据中提取纯文本 |

### 6. chrome-api.js - Chrome API Promise 封装

**导出对象**：`ChromeAPI`

| 方法 | 原生 API | 返回值 |
|------|----------|--------|
| `getCurrentTab()` | `chrome.tabs.query` | `Promise<Tab>` |
| `storageGet(keys)` | `chrome.storage.local.get` | `Promise<Object>` |
| `storageSet(items)` | `chrome.storage.local.set` | `Promise<void>` |
| `sendMessage(msg)` | `chrome.runtime.sendMessage` | `Promise<any>` |

---

## 数据流分析

### 字幕捕获流程

```
用户播放视频
    │
    ▼
浏览器发起字幕请求 (fetch/XHR)
    │
    ▼
inject.js 拦截请求
    │ 
    │ 解析 URL，判断是否为字幕
    ▼
inject.js 克隆响应数据
    │
    │ window.postMessage
    ▼
content_script.js 接收消息
    │
    │ chrome.runtime.sendMessage
    ▼
background.js 存储数据
    │
    │ 更新 Badge 数字
    ▼
用户点击扩展图标
    │
    ▼
popup.js 从 storage 读取字幕列表
    │
    ▼
渲染字幕选择器
```

### AI 总结流程

```
用户点击"总结"按钮
    │
    ▼
popup.js 获取选中字幕内容
    │
    │ 使用 extractSubtitleText() 解析
    ▼
popup.js 建立长连接
    │
    │ chrome.runtime.connect('summarize-stream')
    ▼
发送开始消息 { action: 'start', subtitle, config }
    │
    ▼
background.js 构造 API 请求
    │
    │ 从 storage 读取 API 配置
    ▼
发起 fetch 请求 (stream: true)
    │
    ▼
循环读取 SSE 数据块
    │
    │ 解析 JSON，提取 delta.content
    ▼
通过 port.postMessage 发送 chunk
    │
    ▼
popup.js 接收 chunk
    │
    │ 追加到 streamedContent
    │ 使用 markdownToHtml() 渲染
    ▼
显示在界面上
```

---

## API 参考

### 消息类型

#### 字幕捕获消息

```typescript
interface SubtitleFoundMessage {
    type: 'subtitle-found';
    data: {
        url: string;      // 字幕 URL
        lang: string;     // 语言标识
        data: string;     // 原始字幕内容
    };
}
```

#### AI 连接测试消息

```typescript
// 请求
interface TestConnectionMessage {
    action: 'testConnection';
    config: {
        url: string;
        key: string;
        model: string;
    };
}

// 响应
interface TestConnectionResponse {
    success: boolean;
    status: number;
    latency: number;           // 毫秒
    aiConnectionContent: string;  // AI 返回内容
    data: string;              // 原始响应
}
```

#### AI 总结流式消息

```typescript
// 开始消息
interface SummarizeStartMessage {
    action: 'start';
    subtitle: string;
    lang: string;
    title: string;
    config: ProviderConfig;
}

// 流式响应
type StreamMessage = 
    | { type: 'chunk'; content: string }
    | { type: 'done' }
    | { type: 'error'; error: string };
```

### 存储结构

```typescript
// chrome.storage.local

// 字幕缓存 (按标签页)
interface SubtitleCache {
    [`subtitles_${tabId}`]: Subtitle[];
}

interface Subtitle {
    url: string;
    lang: string;
    data: string;
}

// AI 配置
interface AIConfig {
    providers: Provider[];
    activeProviderId: string;
}

interface Provider {
    id: string;
    name: string;
    url: string;
    key: string;
    model: string;
    systemPrompt?: string;
    prompt?: string;
    maxTokens?: number;
    temperature?: number;
}
```

---

## 开发指南

### 环境准备

1. Chrome 浏览器（推荐最新版）
2. 代码编辑器（推荐 VS Code）
3. 无需 Node.js 或构建工具

### 本地开发流程

1. 修改代码后，进入 `chrome://extensions`
2. 点击扩展的 **刷新** 按钮
3. 如果修改了 `content_script.js` 或 `inject.js`，需要刷新目标页面
4. 如果修改了 `popup.js`，重新打开弹窗即可

### 添加新字幕平台支持

1. **修改 inject.js**：

   ```javascript
   function isSubtitleUrl(url) {
       // 添加新平台的 URL 特征
       if (url.includes('newplatform.com') && url.includes('subtitle')) {
           return true;
       }
       // ...
   }
   ```

2. **修改 utils.js**（如有必要）：

   ```javascript
   function extractSubtitleText(data, url) {
       // 添加新平台的解析逻辑
       if (url.includes('newplatform.com')) {
           // 解析逻辑...
       }
   }
   ```

3. **更新 manifest.json**：

   ```json
   "host_permissions": [
       "*://*.newplatform.com/*"
   ]
   ```

### 添加新 AI 功能

1. **修改 background.js**：添加新的消息处理分支
2. **修改 popup.js**：添加 UI 交互逻辑
3. **修改 options.js**：添加配置项（如需要）

---

## 调试技巧

### 查看后台日志

1. 进入 `chrome://extensions`
2. 找到本扩展
3. 点击 **Service Worker** 链接
4. 在 DevTools Console 中查看日志

### 查看内容脚本日志

1. 打开目标网页（YouTube/Bilibili）
2. 按 F12 打开 DevTools
3. 在 Console 中查看 `[Content]` 或 `[Inject]` 前缀的日志

### 查看弹窗日志

1. 右键点击扩展图标
2. 选择"检查弹出内容"
3. 在 DevTools Console 中查看日志

### 调试存储数据

```javascript
// 在扩展的任意 DevTools Console 中执行
chrome.storage.local.get(null, console.log);
```

---

## 常见问题

### Q: 字幕检测不到？

1. 确保视频已开启字幕
2. 尝试切换字幕语言
3. 刷新页面后重新播放
4. 检查 inject.js 的 URL 匹配规则

### Q: AI 总结失败？

1. 检查 API 配置是否正确
2. 使用"连接测试"验证
3. 查看 background.js 的 Service Worker 日志
4. 确认 API Key 余额充足

### Q: 修改代码后不生效？

1. 刷新扩展（`chrome://extensions` → 刷新按钮）
2. 如果是内容脚本，刷新目标网页
3. 如果是弹窗代码，关闭后重新打开弹窗

---

## 贡献者

- 感谢所有为本项目做出贡献的开发者！

---

*最后更新：2026-02-05*
